<?php

require 'Funcionarios.php';

$secretario = new Funcionario();

	$secretario->departamento = "Secretaria";
	$secretario->salario = 2000;
	$secretario->CPF="107.185.098-22";
	$secretario->recebeAumento();
	$secretario->calculaGanhoAnual();

	$Entrada = new Data();
	$Entrada->dia = 10;
	$Entrada->mes = 25;
	$Entrada->ano = 2018;

	$secretario->dataEntrada=$Entrada;

	$gerente = new Funcionario();

	$gerente->departamento = "Gerencia";
	$gerente->salario = 1111;
	$gerente->CPF="105.205.014-22";
	$gerente->recebeAumento();
	$gerente->calculaGanhoAnual();

	$Entrada = new Data();
	$Entrada->dia = 01;
	$Entrada->mes = 01;
	$Entrada->ano = 2110;

	$gerente->dataEntrada=$Entrada;

	echo $secretario;
	echo $gerente;