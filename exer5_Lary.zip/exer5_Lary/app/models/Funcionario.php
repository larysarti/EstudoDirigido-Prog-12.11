<?php
require '../connection/Connection.php';

class Funcionario{
	public $departamento;
	public $salario;
	public $dataEntrada;
	public $cpf;

	public function __construct() {
        $this->conexao = new Connection();
        $this->conexao = $this->conexao->getConnection();
    }

    public function recebeAumento(){
    	$this += $this->salario * 0.1;

    }

    public function calculaGanhoAnual(){
    	$total = $this->salario * 13;
    	return $total;
    }
    
    public function exibe(){
        return "O funcionario do departamento $this->departamento, funcionario desde $this->dataEntrada possui o salario de R$ $this->salario";
    }

    public function __toString(){
        return $this->exibe();
    }
}

class Data{

    public $dia;
    public $mes;
    public $ano;

    public function mostraData(){
        return "$this->dia/$this->mes/$this->ano";
    }

    public function __toString(){
        return $this->mostraData();
    }

}